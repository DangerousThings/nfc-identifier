package community.revteltech.nfc;

import android.nfc.NfcAdapter;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;

import java.util.List;

/**
 * Raw multi-tag reader bridge (Dangerous Things fork). Reflects into the BYOK-OS
 * {@code NfcAdapter.getRawReader()} → {@code android.nfc.NfcRawReader} (an @hide platform
 * API), so it only resolves on a BYOK-OS build where this app is platform-signed and holds
 * {@code com.byok.permission.NFC_RAW}. Everywhere else the reader is null and
 * {@code isAvailable()} reports false — the JS layer feature-gates on that.
 *
 * All access is reflective (the app is not built against the hidden API); platform-signed
 * apps are exempt from hidden-API enforcement, so the calls succeed there and throw
 * (→ unavailable) on stock Android.
 */
public class RawReaderModule extends ReactContextBaseJavaModule {
    private static final String NAME = "RawReaderModule";

    private final ReactApplicationContext reactContext;
    private Object rawReader; // android.nfc.NfcRawReader
    private boolean resolved;

    RawReaderModule(ReactApplicationContext context) {
        super(context);
        this.reactContext = context;
    }

    @Override
    public String getName() {
        return NAME;
    }

    /** Lazily resolve (and cache) the NfcRawReader handle; throws if unreachable. */
    private synchronized Object reader() throws Exception {
        if (!resolved) {
            resolved = true;
            NfcAdapter adapter = NfcAdapter.getDefaultAdapter(reactContext);
            if (adapter != null) {
                rawReader = adapter.getClass().getMethod("getRawReader").invoke(adapter);
            }
        }
        if (rawReader == null) {
            throw new Exception("NfcRawReader unavailable (not a BYOK-OS platform-signed build)");
        }
        return rawReader;
    }

    @ReactMethod
    public void isAvailable(Promise promise) {
        try {
            reader();
            promise.resolve(true);
        } catch (Throwable t) {
            promise.resolve(false);
        }
    }

    @ReactMethod
    public void setDiscoverMode(boolean enable, Promise promise) {
        try {
            Object r = reader();
            r.getClass().getMethod("setDiscoverMode", boolean.class).invoke(r, enable);
            promise.resolve(null);
        } catch (Throwable t) {
            promise.reject("raw_error", t);
        }
    }

    @ReactMethod
    public void getDiscoveredTargets(Promise promise) {
        try {
            Object r = reader();
            Object listObj = r.getClass().getMethod("getDiscoveredTargets").invoke(r);
            List<?> list = (List<?>) listObj;
            WritableArray out = Arguments.createArray();
            for (Object t : list) {
                WritableMap m = Arguments.createMap();
                m.putInt("discoveryId", t.getClass().getField("discoveryId").getInt(t));
                m.putInt("protocol", t.getClass().getField("protocol").getInt(t));
                byte[] uid = (byte[]) t.getClass().getField("uid").get(t);
                m.putArray("uid", bytesToWritable(uid));
                out.pushMap(m);
            }
            promise.resolve(out);
        } catch (Throwable t) {
            promise.reject("raw_error", t);
        }
    }

    @ReactMethod
    public void select(int discoveryId, Promise promise) {
        try {
            Object r = reader();
            r.getClass().getMethod("select", int.class).invoke(r, discoveryId);
            promise.resolve(null);
        } catch (Throwable t) {
            promise.reject("raw_error", t);
        }
    }

    @ReactMethod
    public void transceive(ReadableArray data, Promise promise) {
        try {
            Object r = reader();
            byte[] in = readableToBytes(data);
            Object respObj = r.getClass()
                    .getMethod("transceive", byte[].class)
                    .invoke(r, (Object) in);
            byte[] resp = (byte[]) respObj;
            promise.resolve(resp == null ? null : bytesToWritable(resp));
        } catch (Throwable t) {
            promise.reject("raw_error", t);
        }
    }

    @ReactMethod
    public void sleep(Promise promise) {
        try {
            Object r = reader();
            r.getClass().getMethod("sleep").invoke(r);
            promise.resolve(null);
        } catch (Throwable t) {
            promise.reject("raw_error", t);
        }
    }

    private static byte[] readableToBytes(ReadableArray a) {
        byte[] b = new byte[a.size()];
        for (int i = 0; i < a.size(); i++) {
            b[i] = (byte) (a.getInt(i) & 0xff);
        }
        return b;
    }

    private static WritableArray bytesToWritable(byte[] b) {
        WritableArray a = Arguments.createArray();
        for (byte x : b) {
            a.pushInt(x & 0xff);
        }
        return a;
    }
}
