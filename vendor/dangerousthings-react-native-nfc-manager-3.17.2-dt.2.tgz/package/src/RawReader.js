/**
 * Raw multi-tag NFC reader — the Dangerous Things fork extension.
 *
 * Drives the BYOK-OS `NfcRawReader` binder (manual anti-collision: hold multiple tags,
 * select/halt at will, transceive to any, in-field tag-to-tag copy — incl. the ISO 15693
 * slot system). Android-only, and only on a BYOK-OS build where this app is platform-signed
 * and holds `com.byok.permission.NFC_RAW`. Everywhere else `isAvailable()` returns false and
 * the other methods reject — so a cross-platform app can feature-gate on `isAvailable()`.
 *
 *   import {RawReader} from '@dangerousthings/react-native-nfc-manager';
 *   if (await RawReader.isAvailable()) {
 *     await RawReader.setDiscoverMode(true);
 *     const targets = await RawReader.getDiscoveredTargets(); // [{discoveryId, protocol, uid}]
 *     await RawReader.select(targets[0].discoveryId);
 *     const block0 = await RawReader.readBlock(targets[0].uid, 0);  // NFC-V addressed read
 *   }
 */
import {NativeModules} from 'react-native';
import {
  i93ReadSingleBlock,
  i93WriteSingleBlock,
  i93StayQuiet,
  i93ResetToReady,
} from './i93';

const Native = NativeModules.RawReaderModule; // undefined on iOS / where not built

function requireNative() {
  if (!Native) {
    throw new Error(
      'RawReader: native module unavailable (iOS, or a build without the raw reader).',
    );
  }
  return Native;
}

const RawReader = {
  /**
   * True only where the NfcRawReader binder is reachable (BYOK-OS, platform-signed app
   * holding com.byok.permission.NFC_RAW). Never throws — safe to gate on.
   */
  async isAvailable() {
    if (!Native) {
      return false;
    }
    try {
      return await Native.isAvailable();
    } catch (e) {
      return false;
    }
  },

  /** Enable/disable the raw session; the broker self-supplies the multi-target discovery config. */
  setDiscoverMode(enable) {
    return requireNative().setDiscoverMode(!!enable);
  },

  /** The currently held anti-collision list: [{discoveryId:int, protocol:int, uid:int[]}]. */
  getDiscoveredTargets() {
    return requireNative().getDiscoveredTargets();
  },

  /** Activate a specific held target by its RF discovery id. */
  select(discoveryId) {
    return requireNative().select(discoveryId);
  },

  /** Send a raw frame to the active tag / field; resolves to a byte array (int[]) or null. */
  transceive(bytes) {
    return requireNative().transceive(Array.from(bytes, (b) => b & 0xff));
  },

  /** Halt the active target to Sleep (14443); use stayQuiet() for NFC-V. */
  sleep() {
    return requireNative().sleep();
  },

  // ---- ISO 15693 convenience (built on transceive) ----

  /** Addressed Read-Single-Block. `uid` from getDiscoveredTargets(). */
  readBlock(uid, block) {
    return this.transceive(i93ReadSingleBlock(uid, block));
  },

  /** Addressed Write-Single-Block; resolves to the tag's response (typically [0x00]). */
  writeBlock(uid, block, data) {
    return this.transceive(i93WriteSingleBlock(uid, block, data));
  },

  /**
   * Stay Quiet (halt): drops the tag from anonymous inventory; it still answers addressed
   * reads. The command itself returns nothing, so this resolves to null rather than rejecting.
   */
  async stayQuiet(uid) {
    try {
      return await this.transceive(i93StayQuiet(uid));
    } catch (e) {
      return null; // no response on success — expected
    }
  },

  /** Reset-to-Ready (revive): the tag returns to inventory; resolves to its response ([0x00]). */
  resetToReady(uid) {
    return this.transceive(i93ResetToReady(uid));
  },
};

export default RawReader;
export {RawReader};
