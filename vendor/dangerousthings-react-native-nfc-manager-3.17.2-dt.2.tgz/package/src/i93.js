/**
 * ISO 15693 (NFC-V / T5T) addressed-frame builders for the raw multi-tag reader.
 *
 * Confirmed on lynx / ST54J 2026-09-01: a `uid` as returned by
 * `RawReader.getDiscoveredTargets()` is the NCI pi93 wire order (LSB-first, the E0
 * manufacturer byte last) — which is exactly the order an addressed i93 command carries,
 * so it is used **verbatim, no reversal**. The firmware appends the CRC.
 *
 * Flag 0x22 = Addressed + High-data-rate. On success a read/write answers a response;
 * Stay Quiet answers nothing (see RawReader.stayQuiet, which swallows that).
 *
 * Pure functions, no react-native import — unit-testable on their own.
 */

const FLAG_ADDRESSED = 0x22;
const CMD_READ_SINGLE_BLOCK = 0x20;
const CMD_WRITE_SINGLE_BLOCK = 0x21;
const CMD_STAY_QUIET = 0x02;
const CMD_RESET_TO_READY = 0x26;

/** Accept a byte array or a hex string ("2b789c...") and normalise to an int array. */
function toIntArray(bytes) {
  if (typeof bytes === 'string') {
    const hex = bytes.replace(/[^0-9a-fA-F]/g, '');
    if (hex.length % 2 !== 0) {
      throw new Error(`i93: hex string has odd length: ${bytes}`);
    }
    const out = [];
    for (let i = 0; i < hex.length; i += 2) {
      out.push(parseInt(hex.substr(i, 2), 16));
    }
    return out;
  }
  return Array.from(bytes, (b) => b & 0xff);
}

function i93ReadSingleBlock(uid, block) {
  return [FLAG_ADDRESSED, CMD_READ_SINGLE_BLOCK, ...toIntArray(uid), block & 0xff];
}

function i93WriteSingleBlock(uid, block, data) {
  return [
    FLAG_ADDRESSED,
    CMD_WRITE_SINGLE_BLOCK,
    ...toIntArray(uid),
    block & 0xff,
    ...toIntArray(data),
  ];
}

function i93StayQuiet(uid) {
  return [FLAG_ADDRESSED, CMD_STAY_QUIET, ...toIntArray(uid)];
}

function i93ResetToReady(uid) {
  return [FLAG_ADDRESSED, CMD_RESET_TO_READY, ...toIntArray(uid)];
}

export {
  toIntArray,
  i93ReadSingleBlock,
  i93WriteSingleBlock,
  i93StayQuiet,
  i93ResetToReady,
};
