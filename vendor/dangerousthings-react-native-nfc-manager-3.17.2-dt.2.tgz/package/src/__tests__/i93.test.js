import {
  toIntArray,
  i93ReadSingleBlock,
  i93WriteSingleBlock,
  i93StayQuiet,
  i93ResetToReady,
} from '../i93';

// UID as returned by RawReader.getDiscoveredTargets() is NCI pi93 wire order
// (LSB-first, E0 last) == the order an addressed i93 frame carries.
const uid = [0x2b, 0x78, 0x9c, 0x00, 0x18, 0x01, 0x04, 0xe0]; // E0:04:01:18:00:9C:78:2B

test('read-single-block builds an addressed frame with the UID verbatim', () => {
  expect(i93ReadSingleBlock(uid, 4)).toEqual([
    0x22, 0x20, 0x2b, 0x78, 0x9c, 0x00, 0x18, 0x01, 0x04, 0xe0, 0x04,
  ]);
});

test('write-single-block appends block then data', () => {
  expect(i93WriteSingleBlock(uid, 4, [0x65, 0x79, 0x2e, 0x63])).toEqual([
    0x22, 0x21, 0x2b, 0x78, 0x9c, 0x00, 0x18, 0x01, 0x04, 0xe0, 0x04, 0x65, 0x79, 0x2e, 0x63,
  ]);
});

test('stay-quiet and reset-to-ready carry only flag+cmd+uid', () => {
  expect(i93StayQuiet(uid)).toEqual([0x22, 0x02, ...uid]);
  expect(i93ResetToReady(uid)).toEqual([0x22, 0x26, ...uid]);
});

test('toIntArray accepts a hex string', () => {
  expect(toIntArray('2b789c00180104e0')).toEqual(uid);
});

test('block number is masked to a byte', () => {
  expect(i93ReadSingleBlock(uid, 0x104)[10]).toBe(0x04);
});
